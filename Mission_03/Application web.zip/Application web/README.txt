Amélioration du CLI comparé au 1er livrable
Pour démarrage : 
Aller dans Rendu1 -> Mettre le bon user et password ligne 10 et 11 
Puis il suffit de lancer "interfaceWeb" 